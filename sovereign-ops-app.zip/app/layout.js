
export const metadata = {
  title: 'Sovereign Ops',
  description: 'Empire Reform Generator'
}

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  )
}
